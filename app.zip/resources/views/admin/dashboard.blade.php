@extends('layouts.master')
@section('title','Jobboard Admin')

