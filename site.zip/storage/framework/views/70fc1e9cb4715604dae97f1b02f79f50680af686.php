<?php $__env->startSection('title','Jobboard Admin'); ?>
<?php $__env->startSection('content'); ?>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <form action="<?php echo e(url('admin/jobs/search')); ?>"  method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-inline mb-3">
                                    <div class="input-group" >
                                        <input value="" class="form-control" type="search" placeholder="Search job title" aria-label="Search" name="title">
                                        <div class="input-group-append">
                                            <button class="btn btn-info btn-sm" type="submit">
                                                <i class="fas fa-search fa-fw"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>

                            <table class="table table-bordered table-hover ">
                                <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Employment type</th>
                                    <th>Location</th>
                                    <th>Dead line</th>
                                    <th>Salary</th>
                                    <th>Status</th>
                                    <th>Edit</th>


                                </tr>
                                </thead>
                                <tbody>

<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                    <td><?php echo e($job->title); ?></td>
                    <td><?php echo e($job->employment); ?></td>
                    <td><?php echo e($job->location); ?></td>
                    <td><?php echo e($job->deadline); ?></td>
                    <td><?php echo e($job->salary); ?></td>
                    <td><?php echo e($job->status); ?></td>
                    <td><a href="<?php echo e(url('admin/jobs/edit/'.$job->id)); ?>" class="btn btn-info">Edit</a></td>

                  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>Title</th>
                                    <th>Employment type</th>
                                    <th>Location</th>
                                    <th>Dead line</th>
                                    <th>Salary</th>
                                </tr>
                                </tfoot>
                            </table>
                            <?php echo e($jobs->links()); ?>

                        </div>

                    </div>




                </div>

            </div>

        </div>

    </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\laravelforbegin.loc\resources\views/admin/job.blade.php ENDPATH**/ ?>