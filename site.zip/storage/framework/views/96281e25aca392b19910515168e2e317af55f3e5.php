<script src="frontend/js/vendor/modernizr-3.5.0.min.js"></script>
<script src="frontend/js/vendor/jquery-1.12.4.min.js"></script>
<script src="frontend/js/popper.min.js"></script>
<script src="frontend/js/bootstrap.min.js"></script>
<script src="frontend/js/owl.carousel.min.js"></script>
<script src="frontend/js/isotope.pkgd.min.js"></script>
<script src="frontend/js/ajax-form.js"></script>
<script src="frontend/js/waypoints.min.js"></script>
<script src="frontend/js/jquery.counterup.min.js"></script>
<script src="frontend/js/imagesloaded.pkgd.min.js"></script>
<script src="frontend/js/scrollIt.js"></script>
<script src="frontend/js/jquery.scrollUp.min.js"></script>
<script src="frontend/js/wow.min.js"></script>
<script src="frontend/js/nice-select.min.js"></script>
<script src="frontend/js/jquery.slicknav.min.js"></script>
<script src="frontend/js/jquery.magnific-popup.min.js"></script>
<script src="frontend/js/plugins.js"></script>
<script src="frontend/js/gijgo.min.js"></script>



<!--contact js-->
<script src="frontend/js/contact.js"></script>
<script src="frontend/js/jquery.ajaxchimp.min.js"></script>
<script src="frontend/js/jquery.form.js"></script>
<script src="frontend/js/jquery.validate.min.js"></script>
<script src="frontend/js/mail-script.js"></script>


<script src="frontend/js/main.js"></script>
<?php /**PATH C:\OpenServer\domains\laravelforbegin.loc\resources\views/components/scripts.blade.php ENDPATH**/ ?>