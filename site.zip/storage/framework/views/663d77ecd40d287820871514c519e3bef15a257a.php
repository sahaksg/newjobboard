<?php $__env->startSection('title','Jobboard Admin'); ?>
<?php $__env->startSection('content'); ?>
    <section class="content">
        <?php if(session('status')): ?>
            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        
        
        <form action="<?php echo e(url('admin/jobs/update/'.$job->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="row">
                <div class="col-md-6">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">General</h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">

                            <div class="form-group">
                                <label for="inputName">Job Title</label>
                                <input type="text" id="inputName" class="form-control" name="title"
                                       value="<?php echo e($job->title); ?>">
                            </div>
                            <div class="form-group">
                                <label for="inputDescription">Job Information</label>
                                <textarea id="inputDescription" class="form-control" rows="4"
                                          name="information"><?php echo e($job->information); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="inputStatus">Employment</label>
                                <select id="inputStatus" class="form-control custom-select" name="employment">
                                    <option selected disabled>Select one</option>

                                    <option value="part-time" <?php echo e(($job->employment)=='part-time'?'selected': ''); ?>>Part-Time</option>
                                    <option value="full-time" <?php echo e(($job->employment)=='full-time'?'selected': ''); ?>>Full-Time</option>
                                    <option value="full-time or part-time" <?php echo e(($job->employment)=='full-time or part-time'?'selected': ''); ?>>Full-Time Or Part-Time</option>
                                </select>
                                <div class="form-group">
                                    <label for="inputDescription">Responsibility</label>
                                    <textarea id="inputDescription" class="form-control" rows="4"
                                              name="responce"><?php echo e($job->responce); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="inputDescription">Qualification</label>
                                    <textarea id="inputDescription" class="form-control" rows="4"
                                              name="qualif"><?php echo e($job->qualif); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="inputDescription">Benefisity</label>
                                    <textarea id="inputDescription" class="form-control" rows="4"
                                              name="benef"><?php echo e($job->benef); ?></textarea>
                                </div>
                            </div>


                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <div class="col-md-6">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Other</h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="form-group ">
                                <label for="inputEstimatedBudget">Estimated budget</label>
                                <div class="d-flex">
                                    <input style="width: 10rem" class="form-control" type="text" id="inputEstimatedBudget" name="salary" value="<?php echo e($job->salary); ?>">
                                    <select name="currency">
                                        <option <?php echo e(($job->currency)==''?'selected': ''); ?> value="na">N/A</option>
                                        <option <?php echo e(($job->currency)=='eur'?'selected': ''); ?> value="eur">€</option>
                                        <option <?php echo e(($job->currency)=='usd'?'selected': ''); ?> value="usd">$</option>
                                    </select>
                                </div>

                            </div>
                            <div class="form-group">
                                <label for="inputSpentBudget">Location</label>
                                <input type="text" class="form-control" name="location" value="<?php echo e($job->location); ?>">
                            </div>
                            <div class="form-group">
                                <label for="inputSpentBudget">Company</label>
                                <input type="text" class="form-control" name="company" value="<?php echo e($job->company); ?>">
                            </div>
                            <div class="form-group">
                                <label for="inputEstimatedDuration">Deadline</label>
                                <input type="date" id="inputEstimatedDuration" class="form-control" name="deadline"
                                       value="<?php echo e($job->deadline); ?>">
                            </div>
                            <div class="form-group">
                                <label for="inputStatus">Status</label>
                                <select name="status">
                                    <option value="active" <?php echo e(($job->status)=='active'?'selected': ''); ?>>Active</option>
                                    <option value="expired" <?php echo e(($job->status)=='expired'?'selected': ''); ?>>Expired</option>
                                </select>

                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <a href="<?php echo e(url('admin/jobs')); ?>" class="btn btn-secondary">Cancel</a>
                    <input type="submit" value="Update Job" class="btn btn-success float-right" name="submit">
                </div>
            </div>
        </form>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\laravelforbegin.loc\resources\views/admin/job_edit.blade.php ENDPATH**/ ?>