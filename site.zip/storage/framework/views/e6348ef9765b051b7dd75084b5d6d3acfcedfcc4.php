<?php $__env->startSection('title','Jobboard Admin'); ?>
<?php $__env->startSection('content'); ?>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Position</th>
                                    <th>Name</th>
                                    <th>E-mail</th>
                                    <th>Message</th>
                                    <th>Date</th>
                                    <th>CV</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($applicant->job_title); ?></td>
                                    <td><?php echo e($applicant->name); ?></td>
                                    <td><?php echo e($applicant->email); ?></td>
                                    <td><?php echo e($applicant->description); ?></td>
                                    <td><?php echo e($applicant->created_at); ?></td>
                                    <td><a href='<?php echo e(asset('storage/cv/'.$applicant->resume)); ?>'><?php echo e($applicant->resume); ?></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>Position</th>
                                    <th>Name</th>
                                    <th>E-mail</th>
                                    <th>Message</th>
                                    <th>Date</th>
                                    <th>CV</th>
                                </tr>
                                </tfoot>
                            </table>
                            <?php echo e($applicants->links()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\laravelforbegin.loc\resources\views/admin/applicant.blade.php ENDPATH**/ ?>