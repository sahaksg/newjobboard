<footer class="footer">
        <div class="footer_top">
            <div class="container text-center">


                    <!-- col-xl-3 col-md-6 col-lg-3 -->
                        <div class="footer_widget wow fadeInUp " data-wow-duration="1s" data-wow-delay=".3s">
                            <div class="footer_logo pt-2">
                                <a href="<?php echo e(url('/')); ?>">
                                    <img src="<?php echo e(asset('frontend/img/logo.png')); ?>" alt="">
                                </a>
                            </div>

                            <div class="socail_links">
                                <ul>
                                    <li>
                                        <a href="#">
                                            <i class="ti-facebook"></i>
                                        </a>
                                    </li>

                                    <li>
                                        <a href="#">
                                            <i class="fa fa-linkedin"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                        </div>



            </div>
        </div>
        <div class="copy-right_text wow fadeInUp" data-wow-duration="1.4s" data-wow-delay=".3s">
            <div class="container">
                <div class="footer_border"></div>
                <div class="row">
                    <div class="col-xl-12">
                        <p class="copy_right text-center">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<?php /**PATH C:\OpenServer\domains\laravelforbegin.loc\resources\views/layouts/inc/footer.blade.php ENDPATH**/ ?>