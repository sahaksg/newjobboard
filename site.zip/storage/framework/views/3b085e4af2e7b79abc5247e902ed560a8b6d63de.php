
<?php $__env->startSection('content'); ?>
<div class="bradcam_area bradcam_bg_1">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="bradcam_text">

                </div>
            </div>
        </div>
    </div>
</div>



<div class="job_listing_area plus_padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-1">

            </div>
            <div class="col-lg-11">


                <div class="job_lists m-0">

                    <div class="row">

                        <?php $__currentLoopData = $sql1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-12 col-md-12">
                                <div class="single_jobs white-bg d-flex justify-content-between">
                                    <div class="jobs_left d-flex align-items-center">
                                        <div class="jobs_conetent">
                                            <a href="<?php echo e(url('job/details')); ?>/<?php echo e($item->id); ?>"><h4><?php echo e($item->title); ?></h4></a>
                                            <div class="links_locat d-flex align-items-center">
                                                <div class="location">
                                                    <p> <i class="fa fa-map-marker"></i> <?php echo e($item->location); ?></p>
                                                </div>
                                                <div class="location">
                                                    <p> <i class="fa fa-user-o"></i> <?php echo e($item->company); ?></p>
                                                </div>
                                                <div class="location">

                                                    <p> <i class="fa fa-clock-o"></i> <?php echo e($item->employment); ?></p>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="jobs_right">
                                        <div class="apply_now">
                                            <a href="<?php echo e(url('job/details')); ?>/<?php echo e($item->id); ?>" id="<?php echo e($item->id); ?>" class="btn btn-info">View & Apply Now !</a>
                                        </div>
                                        <div class="date">
                                            <p>Deadline: <?php echo e($item->deadline); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div class='demo-section clearfix'>

                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="pagination_wrap">
                                <ul>
                                    <li><a href='<?php echo e(url('jobs/1')); ?>'> <i class='ti-angle-left'></i> </a></li>
                                <?php for($i = 1; $i <= $str_pag; $i++): ?>
                                        <li><a href="<?php echo e(url('/jobs')); ?>/<?php echo e($i); ?>"><span>0<?php echo e($i); ?></span></a></li>
                                <?php endfor; ?>
                                    <li><a href="<?php echo e(url('/jobs')); ?>/<?php echo e($str_pag); ?>"> <i class='ti-angle-right'></i> </a></li>


                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- job_listing_area_end  -->
<div class="top_companies_area">
    <div class="container">
        <div class="row align-items-center mb-40">
            <div class="col-lg-6 col-md-6">
                <div class="section_title">
                    <h4>Companies we hire for</h4>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3 col-xl-3 col-md-3">
                <div class="single_company" style="text-align: center; background: #F5F7FA">
                    <div class="thumb " style="width: 170px; height: 112px; margin: auto; border:0px solid #F0F0F0">
                        <img src="<?php echo e(url('frontend/img/partner/finswiss.svg')); ?>" alt="finswiss">
                    </div>
                    <a href="#"><h3>FinSwiss</h3></a>

                </div>
            </div>
            <div class="col-lg-3 col-xl-3 col-md-3">
                <div class="single_company" style="text-align: center; background: #F5F7FA">
                    <div class="thumb " style="width: 170px; height: 112px; margin: auto; border:0px solid #F0F0F0">
                        <img src="<?php echo e(url('frontend/img/partner/eurekly.svg')); ?>" alt="eurekly">
                    </div>
                    <a href="#"><h3>Eurekly</h3></a>

                </div>
            </div>
            <div class="col-lg-3 col-xl-3 col-md-3">
                <div class="single_company" style="text-align: center; background: #F5F7FA">
                    <div class="thumb " style="width: 170px; height: 112px; margin: auto; border: 0px solid #F0F0F0">
                        <img src="<?php echo e(url('frontend/img/partner/bringiton.svg')); ?>" alt="bringiton">
                    </div>
                    <a href="#"><h3>BringItOn</h3></a>

                </div>
            </div>
            <div class="col-lg-3 col-xl-3 col-md-3">
                <div class="single_company" style="text-align: center; background: #F5F7FA">
                    <div class="thumb "  style="width: 170px; height: 112px; margin: auto; border: 0px solid #F0F0F0">
                        <img src="<?php echo e(url('frontend/img/partner/ecodigital.svg')); ?>"alt="ecodigital">
                    </div>
                    <a href="#"><h3>Ecodigital</h3></a>

                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\laravelforbegin.loc\resources\views/pages/jobs.blade.php ENDPATH**/ ?>